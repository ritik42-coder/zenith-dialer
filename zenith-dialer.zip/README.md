# Phone 2.2

A premium dialer for Android: SIM calls (make / receive / in-call screen as the default phone app) plus
internet voice and video calls between app users, by mobile number.

Everything you see lives in `www/index.html` — one self-contained screen. Change it and the app updates
by itself on the next launch.

---

## What's new in 2.2

- **Messages-grade motion** — springy press bounce on every tappable thing, rows that tilt and fade under the top edge as you scroll (the same drum effect as the Messages app), springy list entrances from the left or right, shimmer skeletons while lists load, a pulsing missed-call badge.
- **Keypad corner button** — turn the keypad off (Settings → Keypad) and a glowing Keypad button sits bottom right. Tap it and the keypad blooms out from the button; close it with the X, swipe down, or Back, and it collapses back into the button. The label folds away while you scroll down.
- **Call screens open and close with a reveal** — the call expands from where you tapped (or from the avatar for incoming calls) and collapses when it ends.
- **Three more OS call screens** — Nothing OS (mono dots), ColorOS (soft squircle), HarmonyOS (blue glow). Picking a call screen also switches to that OS's answer style; change it any time under Answer style.
- **New themes** — Midnight Pro (the Messages look, now the default), AMOLED, Emerald, Sunset, Rose Quartz, all with a three-colour brand gradient.

## What's new in 2.1

- **Real favourites** — star a contact from its sheet; they appear as a quick-call strip at the top of Contacts (tap to call, hold for details).
- **Recents filters** — All / Missed / Incoming / Outgoing chips with live counts, a call summary line, and a red missed-call badge on the Recents tab.
- **Speed dial** — assign keys 2-9 to a contact, then hold the key on the keypad to call. Assigned keys show a dot.
- **Smart dial** — type letters-as-numbers (e.g. 5646 for "Kabir") and matching contacts appear above the keypad.
- **Blocking that works** — block/unblock from any contact (system-wide when Phone is the default app), plus a Blocked numbers manager in Settings.
- **Working Message / Save contact buttons** — open your SMS app or the contact editor.
- **Contact sheet** now shows the last 3 calls with that number, with staggered entrance animation.
- **Smoother lists** — off-screen rows are skipped while scrolling.

## What's new in 2.0.1

**Build fix.** The adaptive icon no longer ships its own `ic_launcher_background` colour and the icon vectors were renamed to `phone_icon_bg` / `phone_icon_fg` / `phone_icon_mono`, so nothing collides with the Capacitor template any more (that collision is what failed `mergeDebugResources` with *Duplicate resources*).

## What's new in 2.0

**New identity** — the app is called **Phone**, with a new adaptive icon (gradient mark, handset and
sound waves), a themed monochrome icon for Android 13+, and matching notification icon.

**Six call screens** (Settings → Call screen). Tap a card to apply it, then *Preview a call*:
`iOS` · `One UI` · `Pixel` · `HyperOS` · `Glass` · `Cinema` (your own photo or video behind the call).

**Six answer styles** (Settings → Answer style). Each one has a ▶ preview button that opens a live demo call:
- **Slide to answer** — iOS, drag the green knob across
- **Swipe up to answer** — One UI, up answers, down declines
- **Swipe right to answer** — Samsung style, right answers, left declines
- **Tap the buttons** — Pixel, two round buttons
- **Hold to answer** — press and hold, with a filling ring
- **Double tap** — two quick taps on the green button

**Full screen calls.** Incoming calls wake a sleeping screen, show over the lock screen and take the whole
display. Settings has a *Screen-off demo* so you can see the lock-screen call card without locking your phone.

**Mini call window.** Tap the minimise button (or press home during a call) and the call shrinks into a
draggable floating window with mute, speaker, expand and end. On Android it also enters real
picture-in-picture. Settings → *Show demo*.

**Swipe actions, Samsung style.** In Recents and Contacts:
- **Swipe right** — a green Call panel fills in behind the row; past about a third of the width it dials.
- **Swipe left** — two coloured panels slide out, **Call** (green) and **Message** (blue). The row snaps open
  and stays open until you tap a panel or tap the row to close it. Swipe almost the whole way and it calls.
- **Tap** a row for details (contact card with call, video, message, copy, block).

Only one row can be open at a time, the drag is driven by `requestAnimationFrame` and a single
`translate3d`, and the panels never trigger a layout pass while you drag.

**Keypad tab switch.** Settings → App → Keypad. Turn it off and Phone opens on Recents with only
Recents, Contacts and Settings in the bar — the dialler disappears from the tab bar but the in-call keypad
button always stays. The card also has a *See the in-call keypad* button for a one-tap preview.

**Smooth by default.** The whole UI was re-tuned for frame rate: the animated blurred orbs were replaced by
a single static gradient, the full-screen `blur()` on page changes is gone, 22 backdrop-blur and
`transition: all` rules were removed, scroll reveals are throttled to one `requestAnimationFrame`, and the
call timer only touches the DOM when the text actually changes.

**Sound and touch.** Real DTMF dual tones while dialling (the same pairs a telephone exchange hears),
adjustable volume, and haptics on every key.

**Look and feel.** Eight themes with live preview cards (Aurora, Midnight, Nebula, Ember, Graphite, Sakura,
Mint, Ocean), animated page transitions, staggered list reveals, a morphing keypad icon that opens and
closes the in-call keypad, scroll-reactive headers, and a floating glass tab bar.

**Call background.** Settings → Call background → *Photo* or *Video* picks from your gallery. Images are
downscaled and stored on the device; the choice survives restarts.

---

## One-time Firebase setup (project: bharatchat-d37fa)

1. Project settings → Your apps → Add app → Android. Package name: `com.zenith.dialer`.
   Download `google-services.json` and upload it to the GitHub repo root (next to `zenith-dialer.zip`).
2. Authentication → Sign-in method → enable **Email/Password** (the app uses number + 6-digit PIN).
3. Realtime Database → Rules → add the `callApp` block inside "rules".
4. Cloudflare: create a Worker, paste the calling worker, add the secret `FIREBASE_SA`.
5. In the app: Settings → Internet calling → paste the worker link, then set up your number and PIN.

## Building

Push to `main` and GitHub Actions builds the APK (artifact: **Phone-APK**). Locally:

```
node native/config.js
npm install
npx cap add android
bash native/apply.sh
npx cap sync android
cd android && ./gradlew assembleDebug
```

`native/apply.sh` copies the Java sources, the manifest, and the whole `native/res` icon set into the
generated Android project.

## Notes

- To receive real calls, set Phone as the default phone app (the bar at the top of the keypad).
- Permissions: calls, contacts, call log, notifications, microphone and camera (video calls).
- The UI runs in a normal browser too, with a built-in demo bridge — handy for trying call screens
  without installing anything.
