# Zenith Dialer 2

SIM calls (make/receive) + internet voice/video calls between app users, by mobile number.

## One-time Firebase setup (project: bharatchat-d37fa)
1. Project settings > Your apps > Add app > Android. Package name: `com.zenith.dialer`.
   Download `google-services.json` and upload it to the GitHub repo root (next to `zenith-dialer.zip`).
2. Authentication > Sign-in method > enable **Email/Password** (the app uses number + 6-digit PIN).
3. Realtime Database > Rules > add the `callApp` block from the chat message inside "rules".
4. Cloudflare: create a new Worker, paste the calling worker, add the secret `FIREBASE_SA` (same value as your chat worker), deploy.
5. In the app: Settings > Internet calling > paste the worker link. Then set up your number and PIN.

## Updating
Upload the new zip over the old one in GitHub. Netlify and the APK rebuild by themselves.
