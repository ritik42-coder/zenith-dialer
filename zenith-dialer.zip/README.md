# Zenith Dialer

A real phone app: makes calls and receives calls over your SIM (no internet needed for calls).

## Setup (about 10 minutes, no coding)

1. **GitHub**: create a new repository, click "uploading an existing file", drag in everything from this zip
   (including the hidden `.github` folder), then Commit.
   If `.github` did not upload: Add file > Create new file, name it `.github/workflows/build-apk.yml`, paste the contents from the zip.
2. **Build the APK**: open the repo's **Actions** tab, wait for "Build APK" to turn green (about 5 minutes),
   click it, download **ZenithDialer-APK** at the bottom, unzip, install `app-debug.apk` on your phone.
3. **Netlify** (so you never rebuild the APK for design changes): Add new site > Import from GitHub > pick this repo > Deploy.
   You will get a link like `https://your-name.netlify.app`.
4. **Connect them**: in GitHub open `SITE_URL.txt`, click the pencil, replace the text with your Netlify link, Commit.
   Wait for Actions to finish again and install the new APK once. From now on, edit `www/index.html` and the app updates by itself.
5. **First open on the phone**: allow the permissions, then tap "Set as default phone app" and choose Zenith Dialer.
   Without this step, incoming calls will show on the normal phone screen instead.

## Notes
- Android only. Works with any SIM, any carrier. Dual SIM: Android asks which SIM when you call.
- Call audio itself is handled by Android and the carrier; this app controls the screens and call actions.
- The APK also contains a copy of the screen, so the app still works if Netlify is unreachable.
