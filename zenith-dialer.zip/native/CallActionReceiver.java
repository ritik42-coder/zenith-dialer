package com.zenith.dialer;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telecom.TelecomManager;

/** Answer / decline straight from the incoming-call notification (lock screen included). */
public class CallActionReceiver extends BroadcastReceiver {
    public static final String ANSWER = "com.zenith.dialer.ANSWER";
    public static final String DECLINE = "com.zenith.dialer.DECLINE";
    public static final String HANGUP = "com.zenith.dialer.HANGUP";

    @Override public void onReceive(Context c, Intent i) {
        String a = i == null ? "" : i.getAction();
        try {
            TelecomManager t = (TelecomManager) c.getSystemService(Context.TELECOM_SERVICE);
            if (t != null) {
                if (ANSWER.equals(a)) t.acceptRingingCall();
                else if (DECLINE.equals(a) || HANGUP.equals(a)) t.endCall();
            }
        } catch (Throwable ignored) { }
        try {
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(1);
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(4);
        } catch (Throwable ignored) { }
    }
}
