package com.zenith.dialer;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telecom.TelecomManager;

/** Answer / decline straight from the incoming-call notification (lock screen included). */
public class CallActionReceiver extends BroadcastReceiver {
    public static final String ANSWER = "com.zenith.dialer.ANSWER";
    public static final String DECLINE = "com.zenith.dialer.DECLINE";

    @Override public void onReceive(Context c, Intent i) {
        String a = i == null ? "" : i.getAction();
        try {
            TelecomManager t = (TelecomManager) c.getSystemService(Context.TELECOM_SERVICE);
            if (t != null) {
                if (ANSWER.equals(a)) t.acceptRingingCall();
                else if (DECLINE.equals(a)) t.endCall();
            }
        } catch (Exception e) { }
        try {
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(1);
        } catch (Exception e) { }
    }
}
