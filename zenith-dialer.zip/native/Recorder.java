package com.zenith.dialer;

import android.content.Context;
import android.media.MediaRecorder;
import android.os.Environment;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Saves a call to the phone. Android only lets apps record through the microphone, so speaker mode gives the best result. */
public class Recorder {
    static MediaRecorder mr;
    static File file;

    static File dir(Context c) {
        File d = new File(c.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "CallRecordings");
        d.mkdirs();
        return d;
    }

    static boolean isOn() { return mr != null; }

    static synchronized String start(Context c, String label) throws Exception {
        if (mr != null) return file.getAbsolutePath();
        String safe = (label == null ? "call" : label).replaceAll("[^A-Za-z0-9+]", "_");
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        file = new File(dir(c), safe + "_" + stamp + ".m4a");
        int[] sources = { MediaRecorder.AudioSource.MIC, MediaRecorder.AudioSource.VOICE_RECOGNITION };
        Exception last = null;
        for (int src : sources) {
            MediaRecorder r = new MediaRecorder();
            try {
                r.setAudioSource(src);
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                r.setAudioEncodingBitRate(96000);
                r.setAudioSamplingRate(44100);
                r.setOutputFile(file.getAbsolutePath());
                r.prepare();
                r.start();
                mr = r;
                return file.getAbsolutePath();
            } catch (Exception e) { last = e; try { r.release(); } catch (Exception ignored) { } }
        }
        throw last == null ? new Exception("no recorder") : last;
    }

    static synchronized String stop() {
        if (mr == null) return null;
        String p = file == null ? null : file.getAbsolutePath();
        try { mr.stop(); } catch (Exception e) { if (file != null) file.delete(); p = null; }
        try { mr.release(); } catch (Exception ignored) { }
        mr = null;
        return p;
    }
}
