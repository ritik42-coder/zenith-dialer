package com.zenith.dialer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.InCallService;
import androidx.core.app.NotificationCompat;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import java.util.ArrayList;
import java.util.List;

/** Android hands every call (incoming and outgoing) to this service when the app is the default phone app. */
public class CallService extends InCallService {
    static CallService inst;
    static final List<Call> calls = new ArrayList<>();
    static Runnable listener;

    final Call.Callback cb = new Call.Callback() {
        @Override public void onStateChanged(Call c, int s) { fire(); }
        @Override public void onDetailsChanged(Call c, Call.Details d) { fire(); }
    };

    static void fire() {
        if (inst != null) {
            boolean ringing = false;
            for (Call c : calls) if (c.getState() == Call.STATE_RINGING) ringing = true;
            if (!ringing) ((NotificationManager) inst.getSystemService(NOTIFICATION_SERVICE)).cancel(1);
        }
        if (listener != null) listener.run();
    }

    @Override public void onCallAdded(Call c) {
        inst = this;
        calls.add(c);
        c.registerCallback(cb);
        Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (c.getState() == Call.STATE_RINGING) ring(i);
        try { startActivity(i); } catch (Exception e) { }
        fire();
    }

    @Override public void onCallRemoved(Call c) {
        calls.remove(c);
        c.unregisterCallback(cb);
        fire();
    }

    @Override public void onCallAudioStateChanged(CallAudioState s) { fire(); }

    void ring(Intent i) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("calls", "Incoming calls", NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(null, null); // the system already plays the ringtone
            nm.createNotificationChannel(ch);
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new NotificationCompat.Builder(this, "calls")
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle("Incoming call")
            .setContentText("Tap to answer")
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setFullScreenIntent(pi, true)
            .setContentIntent(pi)
            .setOngoing(true)
            .build();
        nm.notify(1, n);
    }

    static JSObject state() {
        JSObject r = new JSObject();
        JSArray a = new JSArray();
        for (Call c : calls) {
            Call.Details d = c.getDetails();
            JSObject o = new JSObject();
            o.put("id", System.identityHashCode(c));
            o.put("number", d.getHandle() == null ? "" : Uri.decode(d.getHandle().getSchemeSpecificPart()));
            o.put("state", name(c.getState()));
            o.put("connectTime", d.getConnectTimeMillis());
            a.put(o);
        }
        r.put("calls", a);
        CallAudioState as = inst == null ? null : inst.getCallAudioState();
        r.put("muted", as != null && as.isMuted());
        r.put("speaker", as != null && as.getRoute() == CallAudioState.ROUTE_SPEAKER);
        return r;
    }

    static String name(int s) {
        switch (s) {
            case Call.STATE_RINGING: return "ringing";
            case Call.STATE_ACTIVE: return "active";
            case Call.STATE_HOLDING: return "holding";
            case Call.STATE_DISCONNECTED:
            case Call.STATE_DISCONNECTING: return "ended";
            default: return "dialing";
        }
    }

    static Call find(int id) {
        for (Call c : calls) if (id != 0 && System.identityHashCode(c) == id) return c;
        for (Call c : calls) if (c.getState() == Call.STATE_RINGING) return c;
        return calls.isEmpty() ? null : calls.get(0);
    }
}
