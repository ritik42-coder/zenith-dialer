package com.zenith.dialer;

import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.ContactsContract;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.InCallService;
import androidx.core.app.NotificationCompat;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import java.util.ArrayList;
import java.util.List;

/** Android hands every call (incoming and outgoing) to this service when the app is the default phone app. */
public class CallService extends InCallService {
    static CallService inst;
    static final List<Call> calls = new ArrayList<>();
    static Runnable listener;
    static String lastNum = "", lastName = "";

    final Call.Callback cb = new Call.Callback() {
        @Override public void onStateChanged(Call c, int s) { fire(); }
        @Override public void onDetailsChanged(Call c, Call.Details d) { fire(); }
        @Override public void onChildrenChanged(Call c, List<Call> kids) { fire(); }
        @Override public void onParentChanged(Call c, Call parent) { fire(); }
    };

    static void fire() {
        if (inst != null) inst.refresh();
        if (listener != null) listener.run();
    }

    static String numberOf(Call c) {
        try {
            Uri h = c.getDetails().getHandle();
            return h == null ? "" : Uri.decode(h.getSchemeSpecificPart());
        } catch (Throwable t) { return ""; }
    }

    /** Contact name for a number (falls back to the number itself). */
    static String who(Context x, String n) {
        if (n == null || n.isEmpty()) return "Unknown";
        if (n.equals(lastNum)) return lastName;
        String r = n;
        try (Cursor q = x.getContentResolver().query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(n)),
                new String[] { ContactsContract.PhoneLookup.DISPLAY_NAME }, null, null, null)) {
            if (q != null && q.moveToFirst() && q.getString(0) != null) r = q.getString(0);
        } catch (Throwable ignored) { }
        lastNum = n; lastName = r;
        return r;
    }

    boolean asleep() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            return !pm.isInteractive() || km.isKeyguardLocked();
        } catch (Throwable t) { return false; }
    }

    /**
     * One place decides what the user sees:
     *  - phone asleep / locked  -> full-screen call UI (started in onCallAdded), no popup
     *  - our app on screen      -> the in-app call UI only, no notification at all
     *  - another app on screen  -> floating mini call card (or a heads-up notification when the
     *                              "display over other apps" permission is not granted)
     */
    void refresh() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Call ring = null, live = null;
        for (Call c : calls) {
            if (c.getParent() != null) continue;
            int s = c.getState();
            if (s == Call.STATE_RINGING) { if (ring == null) ring = c; }
            else if (s != Call.STATE_DISCONNECTED && s != Call.STATE_DISCONNECTING && live == null) live = c;
        }
        boolean away = !MainActivity.visible();
        if (ring == null || !away) nm.cancel(1);
        boolean pop = away && !asleep() && (ring != null || live != null) && MiniOverlay.can(this);
        if (pop) MiniOverlay.show(this); else MiniOverlay.hide();
        if (ring == null && live != null && away && !pop) postOngoing(live); else nm.cancel(4);
    }

    @Override public void onCallAdded(Call c) {
        inst = this;
        calls.add(c);
        c.registerCallback(cb);
        boolean ringing = c.getState() == Call.STATE_RINGING;
        Intent i = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                .putExtra("incoming", ringing);
        boolean away = !MainActivity.visible();
        if (c.getParent() == null) {
            if (ringing) {
                if (asleep()) { wakeScreen(); try { startActivity(i); } catch (Exception e) { } ring(i); }
                else if (away && !MiniOverlay.can(this)) ring(i);
            } else if (away) {
                try { startActivity(i); } catch (Exception e) { }
            }
        }
        fire();
    }

    @Override public void onCallRemoved(Call c) {
        calls.remove(c);
        c.unregisterCallback(cb);
        if (calls.isEmpty()) Recorder.stop();
        fire();
    }

    @Override public void onCallAudioStateChanged(CallAudioState s) { fire(); }

    /** Turns the display on at once, before the app window is even ready. */
    @SuppressWarnings("deprecation")
    void wakeScreen() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP
                    | PowerManager.ON_AFTER_RELEASE, "phone:ring").acquire(8000);
        } catch (Throwable ignored) { }
    }

    PendingIntent act(int code, String action) {
        return PendingIntent.getBroadcast(this, code, new Intent(this, CallActionReceiver.class).setAction(action),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    void ring(Intent i) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("calls", "Incoming calls", NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(null, null); // the system already plays the ringtone
            ch.setShowBadge(true);
            ch.enableVibration(false);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent answer = act(11, CallActionReceiver.ANSWER);
        PendingIntent decline = act(12, CallActionReceiver.DECLINE);
        String number = "";
        for (Call c : calls) if (c.getState() == Call.STATE_RINGING) { number = numberOf(c); break; }
        String title = who(this, number);
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, "calls")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText("Incoming call")
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setFullScreenIntent(pi, true)
                .setContentIntent(pi)
                .setOngoing(true)
                .setAutoCancel(false)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setColor(0xFF4F7BFF);
        boolean styled = false;
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                androidx.core.app.Person person = new androidx.core.app.Person.Builder().setName(title).setImportant(true).build();
                b.setStyle(NotificationCompat.CallStyle.forIncomingCall(person, decline, answer));
                styled = true;
            } catch (Throwable t) { styled = false; }
        }
        if (!styled) b.addAction(R.drawable.ic_stat, "Decline", decline).addAction(R.drawable.ic_stat, "Answer", answer);
        nm.notify(1, b.build());
    }

    /** Ongoing-call notification, only used when the floating card is not allowed. */
    void postOngoing(Call c) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(new NotificationChannel("ongoing_v1", "Ongoing call", NotificationManager.IMPORTANCE_LOW));
        Intent oi = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        PendingIntent pi = PendingIntent.getActivity(this, 5, oi, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent hang = act(13, CallActionReceiver.HANGUP);
        String title = c.getDetails().hasProperty(Call.Details.PROPERTY_CONFERENCE) ? "Conference call" : who(this, numberOf(c));
        long t = c.getDetails().getConnectTimeMillis();
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, "ongoing_v1")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(c.getState() == Call.STATE_ACTIVE ? "Ongoing call" : c.getState() == Call.STATE_HOLDING ? "On hold" : "Calling…")
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setOngoing(true)
                .setContentIntent(pi)
                .setColor(0xFF4F7BFF);
        if (c.getState() == Call.STATE_ACTIVE && t > 0) b.setUsesChronometer(true).setWhen(t);
        boolean styled = false;
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                androidx.core.app.Person person = new androidx.core.app.Person.Builder().setName(title).build();
                b.setStyle(NotificationCompat.CallStyle.forOngoingCall(person, hang));
                styled = true;
            } catch (Throwable x) { styled = false; }
        }
        if (!styled) b.addAction(R.drawable.ic_stat, "Hang up", hang);
        nm.notify(4, b.build());
    }

    static String routeName(CallAudioState s) {
        if (s == null) return "ear";
        switch (s.getRoute()) {
            case CallAudioState.ROUTE_SPEAKER: return "spk";
            case CallAudioState.ROUTE_BLUETOOTH: return "bt";
            case CallAudioState.ROUTE_WIRED_HEADSET: return "wired";
            default: return "ear";
        }
    }

    static JSObject state() {
        JSObject r = new JSObject();
        JSArray a = new JSArray();
        for (Call c : calls) {
            if (c.getParent() != null) continue; // conference members are listed inside their conference
            Call.Details d = c.getDetails();
            JSObject o = new JSObject();
            o.put("id", System.identityHashCode(c));
            o.put("number", d.getHandle() == null ? "" : Uri.decode(d.getHandle().getSchemeSpecificPart()));
            o.put("state", name(c.getState()));
            o.put("connectTime", d.getConnectTimeMillis());
            o.put("conf", d.hasProperty(Call.Details.PROPERTY_CONFERENCE));
            JSArray kids = new JSArray();
            for (Call k : c.getChildren()) kids.put(numberOf(k));
            o.put("kids", kids);
            a.put(o);
        }
        r.put("calls", a);
        CallAudioState as = inst == null ? null : inst.getCallAudioState();
        r.put("muted", as != null && as.isMuted());
        r.put("speaker", as != null && as.getRoute() == CallAudioState.ROUTE_SPEAKER);
        r.put("route", routeName(as));
        r.put("bt", as != null && (as.getSupportedRouteMask() & CallAudioState.ROUTE_BLUETOOTH) != 0);
        r.put("rec", Recorder.isOn());
        return r;
    }

    static String name(int s) {
        switch (s) {
            case Call.STATE_RINGING: return "ringing";
            case Call.STATE_ACTIVE: return "active";
            case Call.STATE_HOLDING: return "holding";
            case Call.STATE_DISCONNECTED:
            case Call.STATE_DISCONNECTING: return "ended";
            default: return "dialing";
        }
    }

    static Call find(int id) {
        for (Call c : calls) if (id != 0 && System.identityHashCode(c) == id) return c;
        for (Call c : calls) if (c.getState() == Call.STATE_RINGING) return c;
        for (Call c : calls) if (c.getParent() == null) return c;
        return calls.isEmpty() ? null : calls.get(0);
    }
}
