package com.zenith.dialer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

/** Receives the "incoming internet call" push from the Cloudflare worker, even when the app is closed. */
public class PushService extends FirebaseMessagingService {
    static final int RING_ID = 2;

    @Override public void onMessageReceived(@NonNull RemoteMessage m) {
        Map<String, String> d = m.getData();
        if (d == null || !"icall".equals(d.get("type"))) return;
        if (MainActivity.fg) return; // app is open: it already hears the call through the database
        showRing(this, d.get("fromName"), d.get("caller"), "video".equals(d.get("kind")));
    }

    static void showRing(Context c, String name, String num, boolean video) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("icalls_v1", "Internet calls", NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            ch.enableVibration(true);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
        Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 21, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String who = (name == null || name.isEmpty()) ? (num == null ? "Unknown" : num) : name;
        Notification n = new NotificationCompat.Builder(c, "icalls_v1")
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle(who)
            .setContentText(video ? "Incoming video call" : "Incoming internet call")
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(pi, true)
            .setContentIntent(pi)
            .setOngoing(true)
            .setTimeoutAfter(45000)
            .build();
        nm.notify(RING_ID, n);
    }

    static void cancelRing(Context c) {
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(RING_ID);
    }
}
