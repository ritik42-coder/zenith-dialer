package com.zenith.dialer;

import java.io.File;
import android.Manifest;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.AudioManager;
import androidx.core.content.ContextCompat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.TelecomManager;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.util.HashSet;
import java.util.Set;

@CapacitorPlugin(name = "Dialer", permissions = {
    @Permission(alias = "phone", strings = { Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS }),
    @Permission(alias = "notif", strings = { "android.permission.POST_NOTIFICATIONS" }),
    @Permission(alias = "media", strings = { Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA })
})
public class DialerPlugin extends Plugin {

    @Override public void load() {
        CallService.listener = () -> notifyListeners("calls", CallService.state());
    }

    boolean isDefault() {
        TelecomManager t = (TelecomManager) getContext().getSystemService(Context.TELECOM_SERVICE);
        return getContext().getPackageName().equals(t.getDefaultDialerPackage());
    }

    JSObject status() {
        JSObject o = new JSObject();
        o.put("defaultDialer", isDefault());
        o.put("perms", getPermissionState("phone") == PermissionState.GRANTED);
        return o;
    }

    @PluginMethod public void status(PluginCall c) { c.resolve(status()); }

    @PluginMethod public void requestAll(PluginCall c) {
        requestPermissionForAliases(new String[] { "phone", "notif", "media" }, c, "permDone");
    }

    @PermissionCallback private void permDone(PluginCall c) { c.resolve(status()); }

    @PluginMethod public void requestDefault(PluginCall c) {
        Intent i;
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = (RoleManager) getContext().getSystemService(Context.ROLE_SERVICE);
            i = rm.createRequestRoleIntent(RoleManager.ROLE_DIALER);
        } else {
            i = new Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, getContext().getPackageName());
        }
        startActivityForResult(c, i, "roleDone");
    }

    @ActivityCallback private void roleDone(PluginCall c, ActivityResult r) { c.resolve(status()); }

    @PluginMethod public void call(PluginCall c) {
        String n = c.getString("number", "");
        try {
            TelecomManager t = (TelecomManager) getContext().getSystemService(Context.TELECOM_SERVICE);
            t.placeCall(Uri.fromParts("tel", n, null), new Bundle());
            c.resolve();
        } catch (SecurityException e) {
            c.reject("Allow phone permission first");
        }
    }

    @PluginMethod public void answer(PluginCall c) {
        Call k = CallService.find(c.getInt("id", 0));
        if (k != null) k.answer(0);
        c.resolve();
    }

    @PluginMethod public void reject(PluginCall c) {
        Call k = CallService.find(c.getInt("id", 0));
        String msg = c.getString("msg", "");
        if (k != null) { if (msg.isEmpty()) k.reject(false, null); else k.reject(true, msg); }
        c.resolve();
    }

    private Call[] pair() {
        Call a = null, b = null;
        for (Call k : CallService.calls) {
            if (k.getParent() != null) continue;
            if (k.getState() == Call.STATE_ACTIVE) a = k; else if (k.getState() == Call.STATE_HOLDING) b = k;
        }
        return new Call[] { a, b };
    }

    /** Conference: join the active call and the held call. */
    @PluginMethod public void merge(PluginCall c) {
        Call[] p = pair();
        try {
            if (p[0] != null && p[0].getDetails().can(Call.Details.CAPABILITY_MERGE_CONFERENCE)) p[0].mergeConference();
            else if (p[0] != null && p[1] != null) p[0].conference(p[1]);
        } catch (Throwable e) { }
        c.resolve();
    }

    /** Switch between the active call and the held call. */
    @PluginMethod public void swap(PluginCall c) {
        Call[] p = pair();
        try {
            if (p[0] != null && p[0].getDetails().can(Call.Details.CAPABILITY_SWAP_CONFERENCE)) p[0].swapConference();
            else if (p[1] != null) p[1].unhold();
        } catch (Throwable e) { }
        c.resolve();
    }

    /** Audio route: ear | spk | bt | wired. */
    @PluginMethod public void route(PluginCall c) {
        String r = c.getString("r", "ear");
        int v = "spk".equals(r) ? CallAudioState.ROUTE_SPEAKER : "bt".equals(r) ? CallAudioState.ROUTE_BLUETOOTH
                : "wired".equals(r) ? CallAudioState.ROUTE_WIRED_HEADSET : CallAudioState.ROUTE_WIRED_OR_EARPIECE;
        if (CallService.inst != null) CallService.inst.setAudioRoute(v);
        c.resolve();
    }

    @PluginMethod public void recStart(PluginCall c) {
        try {
            Context x = getContext();
            ContextCompat.startForegroundService(x, new Intent(x, CallKeepService.class)); // keeps the microphone alive in the background
            JSObject r = new JSObject();
            r.put("path", Recorder.start(x, c.getString("label", "call")));
            c.resolve(r);
        } catch (Throwable e) { c.reject("Recording is blocked on this phone"); }
    }

    @PluginMethod public void recStop(PluginCall c) {
        String path = Recorder.stop();
        try { getContext().stopService(new Intent(getContext(), CallKeepService.class)); } catch (Throwable ignored) { }
        JSObject r = new JSObject();
        r.put("path", path == null ? "" : path);
        c.resolve(r);
    }

    @PluginMethod public void recList(PluginCall c) {
        JSArray a = new JSArray();
        File[] fs = Recorder.dir(getContext()).listFiles();
        if (fs != null) {
            java.util.Arrays.sort(fs, new java.util.Comparator<File>() {
                @Override public int compare(File x, File y) { return Long.compare(y.lastModified(), x.lastModified()); }
            });
            for (File f : fs) {
                JSObject o = new JSObject();
                o.put("name", f.getName());
                o.put("size", f.length());
                o.put("date", f.lastModified());
                o.put("uri", Uri.fromFile(f).toString());
                a.put(o);
            }
        }
        JSObject r = new JSObject();
        r.put("list", a);
        c.resolve(r);
    }

    @PluginMethod public void recDelete(PluginCall c) {
        try { new File(Recorder.dir(getContext()), new File(c.getString("name", "")).getName()).delete(); } catch (Throwable ignored) { }
        c.resolve();
    }

    /** "Display over other apps" access for the floating call card. */
    @PluginMethod public void overlay(PluginCall c) {
        boolean ok = MiniOverlay.can(getContext());
        if (!ok && c.getBoolean("ask", false)) {
            try {
                Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            } catch (Throwable ignored) { }
        }
        JSObject r = new JSObject();
        r.put("granted", ok);
        c.resolve(r);
    }

    /** The web UI has drawn the call screen: fade the window in. */
    @PluginMethod public void uiReady(PluginCall c) {
        MainActivity.reveal();
        c.resolve();
    }

    @PluginMethod public void hangup(PluginCall c) {
        Call k = CallService.find(c.getInt("id", 0));
        if (k != null) k.disconnect();
        c.resolve();
    }

    @PluginMethod public void hold(PluginCall c) {
        Call k = CallService.find(c.getInt("id", 0));
        if (k != null) k.hold();
        c.resolve();
    }

    @PluginMethod public void unhold(PluginCall c) {
        Call k = CallService.find(c.getInt("id", 0));
        if (k != null) k.unhold();
        c.resolve();
    }

    @PluginMethod public void dtmf(PluginCall c) {
        final Call k = CallService.find(c.getInt("id", 0));
        String d = c.getString("digit", "0");
        if (k != null && !d.isEmpty()) {
            k.playDtmfTone(d.charAt(0));
            new Handler(Looper.getMainLooper()).postDelayed(() -> k.stopDtmfTone(), 150);
        }
        c.resolve();
    }

    @PluginMethod public void mute(PluginCall c) {
        if (CallService.inst != null) CallService.inst.setMuted(c.getBoolean("on", false));
        c.resolve();
    }

    @PluginMethod public void speaker(PluginCall c) {
        if (CallService.inst != null)
            CallService.inst.setAudioRoute(c.getBoolean("on", false) ? CallAudioState.ROUTE_SPEAKER : CallAudioState.ROUTE_WIRED_OR_EARPIECE);
        c.resolve();
    }

    @PluginMethod public void calls(PluginCall c) { c.resolve(CallService.state()); }

    @PluginMethod public void contacts(PluginCall c) {
        JSArray a = new JSArray();
        Set<String> seen = new HashSet<>();
        String[] cols = { ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER };
        try (Cursor q = getContext().getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, cols, null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC")) {
            while (q != null && q.moveToNext()) {
                String nm = q.getString(0), nu = q.getString(1);
                if (nm == null || nu == null || !seen.add(nm + nu.replaceAll("\\D", ""))) continue;
                JSObject o = new JSObject();
                o.put("name", nm);
                o.put("number", nu);
                a.put(o);
            }
        } catch (Exception e) { }
        JSObject r = new JSObject();
        r.put("list", a);
        c.resolve(r);
    }

    @PluginMethod public void log(PluginCall c) {
        JSArray a = new JSArray();
        String[] cols = { CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION };
        try (Cursor q = getContext().getContentResolver().query(CallLog.Calls.CONTENT_URI, cols, null, null, CallLog.Calls.DATE + " DESC")) {
            int n = 0;
            while (q != null && q.moveToNext() && n++ < 200) {
                JSObject o = new JSObject();
                o.put("number", q.getString(0));
                o.put("type", q.getInt(1));
                o.put("date", q.getLong(2));
                o.put("duration", q.getLong(3));
                a.put(o);
            }
        } catch (Exception e) { }
        JSObject r = new JSObject();
        r.put("list", a);
        c.resolve(r);
    }

    @PluginMethod public void fcmToken(final PluginCall c) {
        JSObject r = new JSObject();
        try {
            com.google.firebase.messaging.FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t -> {
                JSObject o = new JSObject();
                o.put("token", t.isSuccessful() && t.getResult() != null ? t.getResult() : "");
                c.resolve(o);
            });
        } catch (Throwable e) {
            r.put("token", "");
            c.resolve(r);
        }
    }

    /** Switches the phone into "call" audio mode and starts/stops the keep-alive service for internet calls. */
    @PluginMethod public void audio(PluginCall c) {
        boolean on = c.getBoolean("on", false);
        AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
        am.setMode(on ? AudioManager.MODE_IN_COMMUNICATION : AudioManager.MODE_NORMAL);
        am.setSpeakerphoneOn(on && c.getBoolean("speaker", false));
        Intent svc = new Intent(getContext(), CallKeepService.class).putExtra("video", c.getBoolean("video", false));
        try {
            if (on) ContextCompat.startForegroundService(getContext(), svc);
            else getContext().stopService(svc);
        } catch (Exception e) { }
        c.resolve();
    }

    @PluginMethod public void clearIncoming(PluginCall c) {
        PushService.cancelRing(getContext());
        c.resolve();
    }

    @PluginMethod public void pending(PluginCall c) {
        JSObject r = new JSObject();
        Intent i = getActivity().getIntent();
        Uri d = i == null ? null : i.getData();
        if (d != null && "tel".equals(d.getScheme())) {
            r.put("number", Uri.decode(d.getSchemeSpecificPart()));
            i.setData(null);
        }
        c.resolve(r);
    }

    @Override protected void handleOnNewIntent(Intent i) {
        super.handleOnNewIntent(i);
        Uri d = i.getData();
        if (d != null && "tel".equals(d.getScheme())) {
            JSObject r = new JSObject();
            r.put("number", Uri.decode(d.getSchemeSpecificPart()));
            notifyListeners("dial", r);
        }
    }

    /* ---------- mini window + full screen ---------- */
    /** Android 14+: opens the "full screen notifications" switch so calls can light up a sleeping phone. */
    @PluginMethod public void fullScreen(PluginCall c) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                android.app.NotificationManager nm = (android.app.NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
                if (!nm.canUseFullScreenIntent()) {
                    Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + getContext().getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(i);
                }
            }
        } catch (Throwable ignored) { }
        c.resolve();
    }

    @PluginMethod public void pip(PluginCall c) {
        boolean ok = false;
        try { ok = MainActivity.enterPip(getContext()); } catch (Exception e) { }
        JSObject r = new JSObject();
        r.put("ok", ok);
        c.resolve(r);
    }

    @PluginMethod public void wake(PluginCall c) {
        try {
            getActivity().runOnUiThread(() -> {
                getActivity().getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                        | android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
            });
        } catch (Exception e) { }
        c.resolve();
    }

    @PluginMethod public void sms(PluginCall c) {
        try {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(c.getString("number", ""))));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            c.resolve();
        } catch (Exception e) { c.reject("No messaging app found"); }
    }

    @PluginMethod public void addContact(PluginCall c) {
        try {
            Intent i = new Intent(Intent.ACTION_INSERT_OR_EDIT);
            i.setType(ContactsContract.Contacts.CONTENT_ITEM_TYPE);
            i.putExtra(ContactsContract.Intents.Insert.PHONE, c.getString("number", ""));
            String nm = c.getString("name", "");
            if (nm != null && nm.length() > 0) i.putExtra(ContactsContract.Intents.Insert.NAME, nm);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            c.resolve();
        } catch (Exception e) { c.reject("Could not open contacts"); }
    }

    @PluginMethod public void block(PluginCall c) {
        try {
            android.content.ContentValues v = new android.content.ContentValues();
            v.put(android.provider.BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, c.getString("number", ""));
            getContext().getContentResolver().insert(android.provider.BlockedNumberContract.BlockedNumbers.CONTENT_URI, v);
            c.resolve();
        } catch (Exception e) { c.reject("Make Phone the default app to block system-wide"); }
    }

    @PluginMethod public void unblock(PluginCall c) {
        try {
            android.provider.BlockedNumberContract.unblock(getContext(), c.getString("number", ""));
            c.resolve();
        } catch (Exception e) { c.reject("Could not unblock"); }
    }
}
