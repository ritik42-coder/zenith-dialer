package com.zenith.dialer;

import android.Manifest;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.AudioManager;
import androidx.core.content.ContextCompat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.TelecomManager;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.util.HashSet;
import java.util.Set;

@CapacitorPlugin(name = "Dialer", permissions = {
    @Permission(alias = "phone", strings = { Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_PHONE_STATE }),
    @Permission(alias = "notif", strings = { "android.permission.POST_NOTIFICATIONS" })
})
public class DialerPlugin extends Plugin {

    @Override public void load() {
        CallService.listener = () -> notifyListeners("calls", CallService.state());
    }

    boolean isDefault() {
        TelecomManager t = (TelecomManager) getContext().getSystemService(Context.TELECOM_SERVICE);
        return getContext().getPackageName().equals(t.getDefaultDialerPackage());
    }

    JSObject status() {
        JSObject o = new JSObject();
        o.put("defaultDialer", isDefault());
        o.put("perms", getPermissionState("phone") == PermissionState.GRANTED);
        return o;
    }

    @PluginMethod public void status(PluginCall c) { c.resolve(status()); }

    @PluginMethod public void requestAll(PluginCall c) {
        requestPermissionForAliases(new String[] { "phone", "notif" }, c, "permDone");
    }

    @PermissionCallback private void permDone(PluginCall c) { c.resolve(status()); }

    @PluginMethod public void requestDefault(PluginCall c) {
        Intent i;
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = (RoleManager) getContext().getSystemService(Context.ROLE_SERVICE);
            i = rm.createRequestRoleIntent(RoleManager.ROLE_DIALER);
        } else {
            i = new Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, getContext().getPackageName());
        }
        startActivityForResult(c, i, "roleDone");
    }

    @ActivityCallback private void roleDone(PluginCall c, ActivityResult r) { c.resolve(status()); }

    @PluginMethod public void call(PluginCall c) {
        String n = c.getString("number", "");
        try {
            TelecomManager t = (TelecomManager) getContext().getSystemService(Context.TELECOM_SERVICE);
            t.placeCall(Uri.fromParts("tel", n, null), new Bundle());
            c.resolve();
        } catch (SecurityException e) {
            c.reject("Allow phone permission first");
        }
    }

    @PluginMethod public void answer(PluginCall c) {
        Call k = CallService.find(c.getInt("id", 0));
        if (k != null) k.answer(0);
        c.resolve();
    }

    @PluginMethod public void reject(PluginCall c) {
        Call k = CallService.find(c.getInt("id", 0));
        if (k != null) k.reject(false, null);
        c.resolve();
    }

    @PluginMethod public void hangup(PluginCall c) {
        Call k = CallService.find(c.getInt("id", 0));
        if (k != null) k.disconnect();
        c.resolve();
    }

    @PluginMethod public void hold(PluginCall c) {
        Call k = CallService.find(c.getInt("id", 0));
        if (k != null) k.hold();
        c.resolve();
    }

    @PluginMethod public void unhold(PluginCall c) {
        Call k = CallService.find(c.getInt("id", 0));
        if (k != null) k.unhold();
        c.resolve();
    }

    @PluginMethod public void dtmf(PluginCall c) {
        final Call k = CallService.find(c.getInt("id", 0));
        String d = c.getString("digit", "0");
        if (k != null && !d.isEmpty()) {
            k.playDtmfTone(d.charAt(0));
            new Handler(Looper.getMainLooper()).postDelayed(() -> k.stopDtmfTone(), 150);
        }
        c.resolve();
    }

    @PluginMethod public void mute(PluginCall c) {
        if (CallService.inst != null) CallService.inst.setMuted(c.getBoolean("on", false));
        c.resolve();
    }

    @PluginMethod public void speaker(PluginCall c) {
        if (CallService.inst != null)
            CallService.inst.setAudioRoute(c.getBoolean("on", false) ? CallAudioState.ROUTE_SPEAKER : CallAudioState.ROUTE_WIRED_OR_EARPIECE);
        c.resolve();
    }

    @PluginMethod public void calls(PluginCall c) { c.resolve(CallService.state()); }

    @PluginMethod public void contacts(PluginCall c) {
        JSArray a = new JSArray();
        Set<String> seen = new HashSet<>();
        String[] cols = { ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER };
        try (Cursor q = getContext().getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, cols, null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC")) {
            while (q != null && q.moveToNext()) {
                String nm = q.getString(0), nu = q.getString(1);
                if (nm == null || nu == null || !seen.add(nm + nu.replaceAll("\\D", ""))) continue;
                JSObject o = new JSObject();
                o.put("name", nm);
                o.put("number", nu);
                a.put(o);
            }
        } catch (Exception e) { }
        JSObject r = new JSObject();
        r.put("list", a);
        c.resolve(r);
    }

    @PluginMethod public void log(PluginCall c) {
        JSArray a = new JSArray();
        String[] cols = { CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION };
        try (Cursor q = getContext().getContentResolver().query(CallLog.Calls.CONTENT_URI, cols, null, null, CallLog.Calls.DATE + " DESC")) {
            int n = 0;
            while (q != null && q.moveToNext() && n++ < 200) {
                JSObject o = new JSObject();
                o.put("number", q.getString(0));
                o.put("type", q.getInt(1));
                o.put("date", q.getLong(2));
                o.put("duration", q.getLong(3));
                a.put(o);
            }
        } catch (Exception e) { }
        JSObject r = new JSObject();
        r.put("list", a);
        c.resolve(r);
    }

    @PluginMethod public void fcmToken(final PluginCall c) {
        JSObject r = new JSObject();
        try {
            com.google.firebase.messaging.FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t -> {
                JSObject o = new JSObject();
                o.put("token", t.isSuccessful() && t.getResult() != null ? t.getResult() : "");
                c.resolve(o);
            });
        } catch (Throwable e) {
            r.put("token", "");
            c.resolve(r);
        }
    }

    /** Switches the phone into "call" audio mode and starts/stops the keep-alive service for internet calls. */
    @PluginMethod public void audio(PluginCall c) {
        boolean on = c.getBoolean("on", false);
        AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
        am.setMode(on ? AudioManager.MODE_IN_COMMUNICATION : AudioManager.MODE_NORMAL);
        am.setSpeakerphoneOn(on && c.getBoolean("speaker", false));
        Intent svc = new Intent(getContext(), CallKeepService.class).putExtra("video", c.getBoolean("video", false));
        try {
            if (on) ContextCompat.startForegroundService(getContext(), svc);
            else getContext().stopService(svc);
        } catch (Exception e) { }
        c.resolve();
    }

    @PluginMethod public void clearIncoming(PluginCall c) {
        PushService.cancelRing(getContext());
        c.resolve();
    }

    @PluginMethod public void pending(PluginCall c) {
        JSObject r = new JSObject();
        Intent i = getActivity().getIntent();
        Uri d = i == null ? null : i.getData();
        if (d != null && "tel".equals(d.getScheme())) {
            r.put("number", Uri.decode(d.getSchemeSpecificPart()));
            i.setData(null);
        }
        c.resolve(r);
    }

    @Override protected void handleOnNewIntent(Intent i) {
        super.handleOnNewIntent(i);
        Uri d = i.getData();
        if (d != null && "tel".equals(d.getScheme())) {
            JSObject r = new JSObject();
            r.put("number", Uri.decode(d.getSchemeSpecificPart()));
            notifyListeners("dial", r);
        }
    }
}
