// The call screen must appear instantly when the phone is asleep, so the UI is always bundled in the APK.
// (A remote UI needs the network before it can paint.) To load the UI from a website anyway,
// put "live https://your-site.netlify.app" in SITE_URL.txt.
const fs = require('fs');
const c = JSON.parse(fs.readFileSync('capacitor.config.json', 'utf8'));
const u = fs.readFileSync('SITE_URL.txt', 'utf8').trim();
const m = u.match(/^live\s+(https:\/\/\S+)/i);
if (m) c.server = { url: m[1], androidScheme: 'https', errorPath: 'index.html' };
c.android = Object.assign(c.android || {}, { backgroundColor: '#06070b' });
fs.writeFileSync('capacitor.config.json', JSON.stringify(c, null, 2));
console.log('Config ready. UI source:', c.server ? m[1] : 'bundled (instant)');
