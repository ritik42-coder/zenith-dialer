// Reads SITE_URL.txt and, if it is a real https link, makes the app load its UI from that website.
const fs = require('fs');
const c = JSON.parse(fs.readFileSync('capacitor.config.json', 'utf8'));
const u = fs.readFileSync('SITE_URL.txt', 'utf8').trim();
if (/^https:\/\//.test(u)) c.server = { url: u, androidScheme: 'https', errorPath: 'index.html' };
fs.writeFileSync('capacitor.config.json', JSON.stringify(c, null, 2));
console.log('Config ready. UI source:', c.server ? u : 'bundled');
