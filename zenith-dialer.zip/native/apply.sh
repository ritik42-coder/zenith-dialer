set -e
P=android/app/src/main/java/com/zenith/dialer
cp native/*.java "$P/"
cp native/AndroidManifest.xml android/app/src/main/AndroidManifest.xml

# --- app identity: name "Phone" + new adaptive icon set ---
mkdir -p android/app/src/main/res
cp -r native/res/* android/app/src/main/res/

sed -i 's/minSdkVersion = 2[0-2]/minSdkVersion = 23/' android/variables.gradle || true

# Firebase (push for internet calls). google-services.json is optional for the first build.
for f in google-services.json ../google-services.json; do
  if [ -f "$f" ]; then cp "$f" android/app/google-services.json; echo "google-services.json added"; break; fi
done
grep -q "gms:google-services" android/build.gradle || sed -i "/com.android.tools.build:gradle/a\        classpath 'com.google.gms:google-services:4.4.2'" android/build.gradle
grep -q "gms.google-services" android/app/build.gradle || echo "apply plugin: 'com.google.gms.google-services'" >> android/app/build.gradle
cat >> android/app/build.gradle <<'GRADLE'

dependencies {
    implementation platform('com.google.firebase:firebase-bom:33.1.2')
    implementation 'com.google.firebase:firebase-messaging'
}
GRADLE
