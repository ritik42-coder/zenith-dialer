set -e
P=android/app/src/main/java/com/zenith/dialer
cp native/*.java "$P/"
cp native/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
sed -i 's/minSdkVersion = 2[0-2]/minSdkVersion = 23/' android/variables.gradle || true
