package com.zenith.dialer;

import android.app.PictureInPictureParams;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.View;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

/**
 * Phone — the whole app is one web screen, so this activity mostly makes sure the
 * call screen can take over a locked / sleeping phone and can shrink into a
 * floating mini window (picture-in-picture).
 */
public class MainActivity extends BridgeActivity {
    static volatile boolean fg = false;
    static MainActivity inst;

    @Override
    public void onCreate(Bundle b) {
        registerPlugin(DialerPlugin.class);
        super.onCreate(b);
        inst = this;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        try {
            getBridge().getWebView().getSettings().setMediaPlaybackRequiresUserGesture(false);
            getBridge().getWebView().setBackgroundColor(0xFF06070B);
        } catch (Exception e) { }
        edgeToEdge();
    }

    /** Draw behind the status and navigation bars so the call screen is truly full screen. */
    void edgeToEdge() {
        try {
            getWindow().setStatusBarColor(0x00000000);
            getWindow().setNavigationBarColor(0x00000000);
            if (Build.VERSION.SDK_INT >= 28) {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
            }
        } catch (Exception e) { }
    }

    void wakeFlags() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        wakeFlags();
        edgeToEdge();
    }

    /** Called from the web UI when the user taps the minimise button. */
    boolean pip() {
        if (Build.VERSION.SDK_INT < 26) return false;
        try {
            PictureInPictureParams.Builder b = new PictureInPictureParams.Builder();
            b.setAspectRatio(new Rational(19, 12));
            enterPictureInPictureMode(b.build());
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static boolean enterPip(Context c) {
        if (c instanceof MainActivity) return ((MainActivity) c).pip();
        return inst != null && inst.pip();
    }

    /** Pressing home during a call drops it into the mini window instead of ending it. */
    @Override public void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (!CallService.calls.isEmpty()) pip();
    }

    @Override public void onResume() {
        super.onResume();
        fg = true;
        PushService.cancelRing(this);
    }

    @Override public void onPause() {
        fg = false;
        super.onPause();
    }
}
