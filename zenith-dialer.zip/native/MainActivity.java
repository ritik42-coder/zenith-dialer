package com.zenith.dialer;

import android.os.Bundle;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    static volatile boolean fg = false;

    @Override
    public void onCreate(Bundle b) {
        registerPlugin(DialerPlugin.class);
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        try { getBridge().getWebView().getSettings().setMediaPlaybackRequiresUserGesture(false); } catch (Exception e) { }
    }

    @Override public void onResume() {
        super.onResume();
        fg = true;
        PushService.cancelRing(this);
    }

    @Override public void onPause() {
        fg = false;
        super.onPause();
    }
}
