package com.zenith.dialer;

import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** A small floating call card over any other app: Answer / Decline when ringing, mute / speaker / end during a call. */
public class MiniOverlay {
    static WindowManager wm;
    static LinearLayout root, btns;
    static TextView title, sub;
    static WindowManager.LayoutParams lp;
    static String mode = "";
    static Context app;
    static final Handler h = new Handler(Looper.getMainLooper());
    static final Runnable tick = new Runnable() { @Override public void run() { if (app != null && root != null) show(app); } };

    static boolean can(Context c) { return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c); }

    static float dp(float v) { return v * app.getResources().getDisplayMetrics().density; }

    static void show(Context c) {
        try {
            app = c.getApplicationContext();
            Call ring = null, live = null;
            for (Call k : CallService.calls) {
                if (k.getParent() != null) continue;
                if (k.getState() == Call.STATE_RINGING) { if (ring == null) ring = k; }
                else if (k.getState() != Call.STATE_DISCONNECTED && live == null) live = k;
            }
            Call main = ring != null ? ring : live;
            if (main == null) { hide(); return; }
            if (root == null) build();
            String m = ring != null ? "ring" : "live";
            if (!m.equals(mode)) { mode = m; buttons(ring != null); }
            boolean conf = main.getDetails().hasProperty(Call.Details.PROPERTY_CONFERENCE);
            title.setText(conf ? "Conference call" : CallService.who(app, CallService.numberOf(main)));
            sub.setText(status(main, ring != null));
            h.removeCallbacks(tick);
            h.postDelayed(tick, 1000);
        } catch (Throwable t) { hide(); }
    }

    static String status(Call k, boolean ring) {
        if (ring) return CallService.calls.size() > 1 ? "Incoming call · waiting" : "Incoming call";
        int s = k.getState();
        if (s == Call.STATE_ACTIVE) {
            long t = k.getDetails().getConnectTimeMillis();
            long sec = t <= 0 ? 0 : Math.max(0, (System.currentTimeMillis() - t) / 1000);
            return String.format("%d:%02d", sec / 60, sec % 60);
        }
        if (s == Call.STATE_HOLDING) return "On hold";
        return "Calling…";
    }

    static void build() {
        wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
        root = new LinearLayout(app);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xF2161A22);
        g.setCornerRadius(dp(32));
        root.setBackground(g);
        root.setPadding((int) dp(18), (int) dp(10), (int) dp(10), (int) dp(10));
        root.setElevation(dp(12));
        LinearLayout col = new LinearLayout(app);
        col.setOrientation(LinearLayout.VERTICAL);
        title = new TextView(app);
        title.setTextColor(0xFFFFFFFF); title.setTextSize(16); title.setSingleLine(true); title.setEllipsize(TextUtils.TruncateAt.END);
        sub = new TextView(app);
        sub.setTextColor(0xB3FFFFFF); sub.setTextSize(12);
        col.addView(title); col.addView(sub);
        root.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        btns = new LinearLayout(app);
        root.addView(btns);
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        lp = new WindowManager.LayoutParams(app.getResources().getDisplayMetrics().widthPixels - (int) dp(20),
                WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = (int) dp(30);
        root.setOnTouchListener(new View.OnTouchListener() {
            float y0; int s0; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: y0 = e.getRawY(); s0 = lp.y; moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawY() - y0) > dp(8)) moved = true;
                        if (moved) { lp.y = Math.max(0, s0 + (int) (e.getRawY() - y0)); try { wm.updateViewLayout(root, lp); } catch (Throwable t) { } }
                        return true;
                    case MotionEvent.ACTION_UP: if (!moved) open(); return true;
                }
                return false;
            }
        });
        root.setAlpha(0f);
        root.setTranslationY(-dp(60));
        wm.addView(root, lp);
        root.animate().alpha(1f).translationY(0f).setDuration(220).start();
    }

    static void buttons(boolean ring) {
        btns.removeAllViews();
        if (ring) {
            btns.addView(circle(R.drawable.ic_ov_phone, 0xFFFF3B30, 135f, new View.OnClickListener() {
                @Override public void onClick(View v) { Call k = CallService.find(0); if (k != null) k.reject(false, null); }
            }));
            btns.addView(circle(R.drawable.ic_ov_phone, 0xFF30D158, 0f, new View.OnClickListener() {
                @Override public void onClick(View v) { Call k = CallService.find(0); if (k != null) k.answer(0); }
            }));
            return;
        }
        CallAudioState a = CallService.inst == null ? null : CallService.inst.getCallAudioState();
        ImageView mute = circle(R.drawable.ic_ov_mic, 0x33FFFFFF, 0f, new View.OnClickListener() {
            @Override public void onClick(View v) {
                CallService s = CallService.inst;
                if (s == null) return;
                CallAudioState x = s.getCallAudioState();
                boolean on = x == null || !x.isMuted();
                s.setMuted(on);
                tint(v, on);
            }
        });
        tint(mute, a != null && a.isMuted());
        ImageView spk = circle(R.drawable.ic_ov_spk, 0x33FFFFFF, 0f, new View.OnClickListener() {
            @Override public void onClick(View v) {
                CallService s = CallService.inst;
                if (s == null) return;
                CallAudioState x = s.getCallAudioState();
                boolean on = x == null || x.getRoute() != CallAudioState.ROUTE_SPEAKER;
                s.setAudioRoute(on ? CallAudioState.ROUTE_SPEAKER : CallAudioState.ROUTE_WIRED_OR_EARPIECE);
                tint(v, on);
            }
        });
        tint(spk, a != null && a.getRoute() == CallAudioState.ROUTE_SPEAKER);
        btns.addView(mute);
        btns.addView(spk);
        btns.addView(circle(R.drawable.ic_ov_phone, 0xFFFF3B30, 135f, new View.OnClickListener() {
            @Override public void onClick(View v) { Call k = CallService.find(0); if (k != null) k.disconnect(); }
        }));
    }

    static void tint(View v, boolean on) {
        ((GradientDrawable) v.getBackground()).setColor(on ? 0xFFFFFFFF : 0x33FFFFFF);
        ((ImageView) v).setColorFilter(on ? 0xFF111111 : 0xFFFFFFFF);
    }

    static ImageView circle(int res, int color, float rot, View.OnClickListener l) {
        ImageView v = new ImageView(app);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        v.setBackground(g);
        v.setImageResource(res);
        v.setColorFilter(0xFFFFFFFF);
        v.setRotation(rot);
        int p = (int) dp(11);
        v.setPadding(p, p, p, p);
        LinearLayout.LayoutParams q = new LinearLayout.LayoutParams((int) dp(46), (int) dp(46));
        q.leftMargin = (int) dp(8);
        v.setLayoutParams(q);
        v.setOnClickListener(l);
        return v;
    }

    static void open() {
        try {
            app.startActivity(new Intent(app, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
        } catch (Throwable ignored) { }
    }

    static void hide() {
        h.removeCallbacks(tick);
        if (root != null) {
            try { wm.removeView(root); } catch (Throwable ignored) { }
            root = null;
            mode = "";
        }
    }
}
